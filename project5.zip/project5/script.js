var database = [
{
	username: "jignesh",
	password: "jignesh22"
 }
];

var newsfeed = [
{
	username: "shrinil",
	timeline: "So tired from all that learning"
},
{
	username: "ajay",
	timeline: "need to learn more"
}
];

var userNamePrompt = prompt("What is your username?");
var passwordPrompt = prompt("What is your password?");

function signIn(user, pass) {
	if (user === database[0].username && 
		pass === database[0].password {
        console.log(newsFeed);
	} else {
		alert("Sorry, wrong username and password");
    }
}

signIn(userNamePrompt, passwordPrompt);